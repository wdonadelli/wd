<?php
echo "\nFILES: ";
print_r($_FILES);
echo "\nREQUEST: ";
print_r($_REQUEST);
?>
